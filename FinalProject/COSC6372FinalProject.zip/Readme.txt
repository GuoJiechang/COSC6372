1.Create a new Unity3D project
2.Import the unity package as customer asset
3.Put the face_ids.txt files in the place where COSC6372FinalProject.sln is.
4.There are three scene in this project.
Scene1: RenderWing, show the area for each wings
Scene2: SpeedControl, the scene for control speed and frequency of the butterfly
Scene3: PathFollowing, the scene for butterfly to follow a user-defined path.
